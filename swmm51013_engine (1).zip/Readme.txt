Contents of this archive:

source5_1_013.zip
=================
Contains the source code for the computational engine
of SWMM 5.1.013. Consult the included Roadmap.txt file
for an overview of the various code modules.

makefiles.zip
=============
Contains "make" files for compiling the SWMM 5.1 engine
DLL and its command line executable with Microsoft C++ 2017
and with GNU C/C++.